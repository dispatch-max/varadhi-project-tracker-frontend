'use client'

import { useState } from 'react'
import { Plus, Search, Filter } from 'lucide-react'
import { ProjectCard } from './project-card'
import { CreateProjectModal } from './create-project-modal'
import { Button } from '@/components/ui/button'
import { useAuthStore } from '@/store/auth.store'

// Mock data — replace with real API later
const MOCK_PROJECTS = [
  {
    id: '1',
    name: 'Varadhi Tracker Frontend',
    description: 'Building the full frontend for the internal project tracker using Next.js and Tailwind CSS.',
    status: 'active',
    completedTasksCount: 12,
    tasksCount: 20,
    endDate: '2026-07-15',
    members: [
      { id: '1', name: 'Suhail H' },
      { id: '2', name: 'Jagdish D' },
    ],
    manager: { name: 'Suhail H' },
  },
  {
    id: '2',
    name: 'Varadhi Tracker Backend',
    description: 'REST API development with Node.js, Express and MongoDB for the project tracker.',
    status: 'active',
    completedTasksCount: 8,
    tasksCount: 18,
    endDate: '2026-07-20',
    members: [
      { id: '2', name: 'Jagdish D' },
      { id: '3', name: 'Arjun R' },
      { id: '4', name: 'Priya S' },
    ],
    manager: { name: 'Jagdish D' },
  },
  {
    id: '3',
    name: 'Mobile App v2',
    description: 'Varadhi Club mobile app redesign with React Native.',
    status: 'on_hold',
    completedTasksCount: 5,
    tasksCount: 15,
    endDate: '2026-08-01',
    members: [
      { id: '1', name: 'Suhail H' },
      { id: '3', name: 'Arjun R' },
    ],
    manager: { name: 'Arjun R' },
  },
  {
    id: '4',
    name: 'Admin Dashboard',
    description: 'Internal admin panel for managing users, roles and system settings.',
    status: 'completed',
    completedTasksCount: 24,
    tasksCount: 24,
    endDate: '2026-05-30',
    members: [
      { id: '1', name: 'Suhail H' },
      { id: '2', name: 'Jagdish D' },
      { id: '3', name: 'Arjun R' },
      { id: '4', name: 'Priya S' },
      { id: '5', name: 'Rahul K' },
    ],
    manager: { name: 'Suhail H' },
  },
  {
    id: '5',
    name: 'Notification Service',
    description: 'Real-time notification system using WebSockets for the Varadhi platform.',
    status: 'active',
    completedTasksCount: 3,
    tasksCount: 10,
    endDate: '2026-08-15',
    members: [
      { id: '2', name: 'Jagdish D' },
    ],
    manager: { name: 'Jagdish D' },
  },
  {
    id: '6',
    name: 'Document Repository',
    description: 'File storage and document management system for the team.',
    status: 'active',
    completedTasksCount: 2,
    tasksCount: 8,
    endDate: '2026-09-01',
    members: [
      { id: '3', name: 'Arjun R' },
      { id: '4', name: 'Priya S' },
    ],
    manager: { name: 'Arjun R' },
  },
]

export function ProjectsList() {
  const { user } = useAuthStore()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [showCreateModal, setShowCreateModal] = useState(false)

  // Filter projects
  const filtered = MOCK_PROJECTS.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase())
    const matchesStatus =
      statusFilter === 'all' || p.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const canCreate = ['admin', 'manager'].includes(user?.role)
  
  // for testing purposes, replace with real permission logic later
// const canCreate = true 

  return (
    <div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">

        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 bg-white placeholder:text-slate-400"
          />
        </div>

        {/* Status Filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 bg-white text-slate-700"
        >
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="on_hold">On Hold</option>
          <option value="completed">Completed</option>
          <option value="archived">Archived</option>
        </select>

        {/* Create Button — only for admin/manager */}
        {canCreate && (
          <Button
            onClick={() => setShowCreateModal(true)}
            className="bg-violet-600 hover:bg-violet-700 flex-shrink-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Project
          </Button>
        )}
      </div>

      {/* Results count */}
      <p className="text-xs text-slate-400 mb-4">
        Showing {filtered.length} project{filtered.length !== 1 ? 's' : ''}
      </p>

      {/* Project Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Filter className="w-5 h-5 text-slate-400" />
          </div>
          <p className="text-sm font-medium text-slate-600">
            No projects found
          </p>
          <p className="text-xs text-slate-400 mt-1">
            Try changing your search or filter
          </p>
        </div>
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <CreateProjectModal
          onClose={() => setShowCreateModal(false)}
          onSuccess={() => {
            setShowCreateModal(false)
            // Will refetch from API later
          }}
        />
      )}

    </div>
  )
}