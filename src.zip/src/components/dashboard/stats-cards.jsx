'use client'

import {
  FolderOpen, ListChecks, CheckCircle2,
  Clock, AlertTriangle, Users
} from 'lucide-react'
import { cn } from '@/utils'

const STATS = [
  {
    label: 'Total Projects',
    key: 'totalProjects',
    icon: FolderOpen,
    color: 'bg-violet-50 text-violet-600',
    trend: '+2 this month',
  },
  {
    label: 'Active Projects',
    key: 'activeProjects',
    icon: FolderOpen,
    color: 'bg-blue-50 text-blue-600',
    trend: 'Currently running',
  },
  {
    label: 'Total Tasks',
    key: 'totalTasks',
    icon: ListChecks,
    color: 'bg-slate-50 text-slate-600',
    trend: 'Across all projects',
  },
  {
    label: 'Completed',
    key: 'completedTasks',
    icon: CheckCircle2,
    color: 'bg-green-50 text-green-600',
    trend: 'Tasks finished',
  },
  {
    label: 'In Progress',
    key: 'inProgressTasks',
    icon: Clock,
    color: 'bg-amber-50 text-amber-600',
    trend: 'Being worked on',
  },
  {
    label: 'Overdue',
    key: 'overdueTasks',
    icon: AlertTriangle,
    color: 'bg-red-50 text-red-600',
    trend: 'Needs attention',
  },
]

export function StatsCards({ stats }) {
  // Use mock data if no real data yet
  const data = stats || {
    totalProjects: 8,
    activeProjects: 5,
    totalTasks: 64,
    completedTasks: 38,
    inProgressTasks: 14,
    overdueTasks: 3,
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
      {STATS.map((stat) => {
        const Icon = stat.icon
        return (
          <div
            key={stat.key}
            className="bg-white rounded-xl border border-slate-200 p-4 hover:shadow-sm transition-shadow"
          >
            <div className={cn(
              'w-9 h-9 rounded-lg flex items-center justify-center mb-3',
              stat.color
            )}>
              <Icon className="w-4 h-4" />
            </div>
            <p className="text-2xl font-semibold text-slate-800 leading-none mb-1">
              {data[stat.key] ?? 0}
            </p>
            <p className="text-xs font-medium text-slate-600 mb-1">
              {stat.label}
            </p>
            <p className="text-xs text-slate-400">
              {stat.trend}
            </p>
          </div>
        )
      })}
    </div>
  )
}