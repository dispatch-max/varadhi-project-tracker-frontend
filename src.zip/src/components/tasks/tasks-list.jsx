'use client'

import { useState } from 'react'
import {
  Plus, Search, Calendar,
  AlertTriangle, MoreHorizontal
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { CreateTaskModal } from './create-task-modal'
import { StatusBadge, PriorityBadge, TypeBadge } from './task-badge'
import { useAuthStore } from '@/store/auth.store'
import {
  formatDate, isOverdue,
  getInitials, getAvatarColor, cn
} from '@/utils'

// Mock tasks data
const MOCK_TASKS = [
  {
    id: '1',
    title: 'Build Login Page UI',
    description: 'Create login form with email, password, validation and error states.',
    type: 'feature',
    priority: 'high',
    status: 'completed',
    project: { id: '1', name: 'Varadhi Tracker Frontend' },
    assignee: { id: '1', name: 'Suhail H' },
    dueDate: '2026-06-10',
    createdAt: '2026-05-01',
  },
  {
    id: '2',
    title: 'Setup MongoDB Schema',
    description: 'Design and implement all database schemas for users, projects and tasks.',
    type: 'infra',
    priority: 'high',
    status: 'completed',
    project: { id: '2', name: 'Varadhi Tracker Backend' },
    assignee: { id: '2', name: 'Jagdish D' },
    dueDate: '2026-06-08',
    createdAt: '2026-05-02',
  },
  {
    id: '3',
    title: 'Kanban Drag & Drop',
    description: 'Implement drag and drop functionality for the Kanban board using dnd-kit.',
    type: 'feature',
    priority: 'high',
    status: 'in_progress',
    project: { id: '1', name: 'Varadhi Tracker Frontend' },
    assignee: { id: '1', name: 'Suhail H' },
    dueDate: '2026-06-20',
    createdAt: '2026-05-10',
  },
  {
    id: '4',
    title: 'JWT Auth Flow',
    description: 'Implement JWT login, token refresh and protected routes.',
    type: 'feature',
    priority: 'critical',
    status: 'in_review',
    project: { id: '2', name: 'Varadhi Tracker Backend' },
    assignee: { id: '2', name: 'Jagdish D' },
    dueDate: '2026-06-15',
    createdAt: '2026-05-08',
  },
  {
    id: '5',
    title: 'File Upload Module',
    description: 'Build document upload with file type validation and progress indicator.',
    type: 'feature',
    priority: 'medium',
    status: 'todo',
    project: { id: '1', name: 'Varadhi Tracker Frontend' },
    assignee: { id: '3', name: 'Arjun R' },
    dueDate: '2026-07-01',
    createdAt: '2026-05-15',
  },
  {
    id: '6',
    title: 'Fix Token Expiry Bug',
    description: 'Auth token expiry not handled — user stays on page instead of redirecting.',
    type: 'bug',
    priority: 'critical',
    status: 'in_progress',
    project: { id: '2', name: 'Varadhi Tracker Backend' },
    assignee: { id: '2', name: 'Jagdish D' },
    dueDate: '2026-06-05',
    createdAt: '2026-05-20',
  },
  {
    id: '7',
    title: 'Research DB Hosting Options',
    description: 'Compare MongoDB Atlas vs Railway vs Supabase for production hosting.',
    type: 'research',
    priority: 'medium',
    status: 'todo',
    project: { id: '2', name: 'Varadhi Tracker Backend' },
    assignee: { id: '3', name: 'Arjun R' },
    dueDate: '2026-06-25',
    createdAt: '2026-05-18',
  },
  {
    id: '8',
    title: 'Dashboard Charts UI',
    description: 'Build burndown chart and task analytics using Recharts.',
    type: 'feature',
    priority: 'medium',
    status: 'todo',
    project: { id: '1', name: 'Varadhi Tracker Frontend' },
    assignee: { id: '1', name: 'Suhail H' },
    dueDate: '2026-07-05',
    createdAt: '2026-05-22',
  },
]

export function TasksList() {
  const { user } = useAuthStore()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [priorityFilter, setPriorityFilter] = useState('all')
  const [showCreateModal, setShowCreateModal] = useState(false)

  // Filter tasks
  const filtered = MOCK_TASKS.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.project.name.toLowerCase().includes(search.toLowerCase())
    const matchesStatus =
      statusFilter === 'all' || t.status === statusFilter
    const matchesPriority =
      priorityFilter === 'all' || t.priority === priorityFilter
    return matchesSearch && matchesStatus && matchesPriority
  })

  return (
    <div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">

        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search tasks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 bg-white placeholder:text-slate-400"
          />
        </div>

        {/* Status Filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 bg-white text-slate-700"
        >
          <option value="all">All Status</option>
          <option value="todo">To Do</option>
          <option value="in_progress">In Progress</option>
          <option value="in_review">In Review</option>
          <option value="completed">Completed</option>
        </select>

        {/* Priority Filter */}
        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 bg-white text-slate-700"
        >
          <option value="all">All Priority</option>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="critical">Critical</option>
        </select>

        {/* Create Button */}
        <Button
          onClick={() => setShowCreateModal(true)}
          className="bg-violet-600 hover:bg-violet-700 flex-shrink-0"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Task
        </Button>
      </div>

      {/* Results count */}
      <p className="text-xs text-slate-400 mb-4">
        Showing {filtered.length} task{filtered.length !== 1 ? 's' : ''}
      </p>

      {/* Tasks Table */}
      {filtered.length > 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 w-full">
                    Task
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 whitespace-nowrap">
                    Project
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 whitespace-nowrap">
                    Type
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 whitespace-nowrap">
                    Priority
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 whitespace-nowrap">
                    Status
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 whitespace-nowrap">
                    Assignee
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 whitespace-nowrap">
                    Due Date
                  </th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((task) => {
                  const overdue =
                    task.dueDate &&
                    task.status !== 'completed' &&
                    isOverdue(task.dueDate)

                  return (
                    <tr
                      key={task.id}
                      className="hover:bg-slate-50 transition-colors"
                    >
                      {/* Title */}
                      <td className="px-4 py-3">
                        <p className="text-sm font-medium text-slate-800 truncate max-w-xs">
                          {task.title}
                        </p>
                        {task.description && (
                          <p className="text-xs text-slate-400 truncate max-w-xs mt-0.5">
                            {task.description}
                          </p>
                        )}
                      </td>

                      {/* Project */}
                      <td className="px-4 py-3">
                        <span className="text-xs text-slate-500 whitespace-nowrap">
                          {task.project.name}
                        </span>
                      </td>

                      {/* Type */}
                      <td className="px-4 py-3">
                        <TypeBadge type={task.type} />
                      </td>

                      {/* Priority */}
                      <td className="px-4 py-3">
                        <PriorityBadge priority={task.priority} />
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3">
                        <StatusBadge status={task.status} />
                      </td>

                      {/* Assignee */}
                      <td className="px-4 py-3">
                        {task.assignee ? (
                          <div className="flex items-center gap-2">
                            <div className={cn(
                              'w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-semibold flex-shrink-0',
                              getAvatarColor(task.assignee.name)
                            )}>
                              {getInitials(task.assignee.name)}
                            </div>
                            <span className="text-xs text-slate-600 whitespace-nowrap">
                              {task.assignee.name}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">
                            Unassigned
                          </span>
                        )}
                      </td>

                      {/* Due Date */}
                      <td className="px-4 py-3">
                        {task.dueDate ? (
                          <div className={cn(
                            'flex items-center gap-1 text-xs whitespace-nowrap',
                            overdue ? 'text-red-500' : 'text-slate-500'
                          )}>
                            {overdue && (
                              <AlertTriangle className="w-3 h-3" />
                            )}
                            <Calendar className="w-3 h-3" />
                            {formatDate(task.dueDate, 'MMM dd')}
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">—</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3">
                        <button className="text-slate-400 hover:text-slate-600 p-1 rounded hover:bg-slate-100">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center mx-auto mb-3">
            <Search className="w-5 h-5 text-slate-400" />
          </div>
          <p className="text-sm font-medium text-slate-600">No tasks found</p>
          <p className="text-xs text-slate-400 mt-1">
            Try changing your filters or create a new task
          </p>
        </div>
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <CreateTaskModal
          onClose={() => setShowCreateModal(false)}
          onSuccess={() => setShowCreateModal(false)}
        />
      )}

    </div>
  )
}